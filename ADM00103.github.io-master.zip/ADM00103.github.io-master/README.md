<h1 align="center">Hi 👋, I'm Victor Dunaev Adm</h1>
<h3 align="center">Ethical Hacker | Assistant at Security | Web Developer </h3>

- 🔭 I’m currently working on **ADM**

- 🌱 I’m currently learning **web development and system administrator**

- 📝 I regularly write articles on [https://t.me/NETSTALKER_RU](https://t.me/NETSTALKER_RU)

- 💬 Ask me about **Ethical Hacking, PHP, Youtube, Games, System Administrator**

- 📫 How to reach me **https://t.me/MAD101_bot**

<h3 align="left">Connect with me:</h3>
<p align="left">
<a href="https://t.me/NETSTALKER_RU" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/twitter.svg" alt="ADM00103" height="30" width="40" /></a>
<a href="https://t.me/NETSTALKER_RU" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/linked-in-alt.svg" alt="ADM00103" height="30" width="40" /></a>
<a href="https://t.me/NETSTALKER_RU" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/instagram.svg" alt="ADM00103" height="30" width="40" /></a>
<a href="https://www.youtube.com/c/ADM00103" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/youtube.svg" alt="ADM00103" height="30" width="40" /></a>
</p>


<p>&nbsp;<img align="center" src="https://github-readme-stats.vercel.app/api?username=ADM00103" alt="ADM00103" /></p>

<p>&nbsp;<img align="center" src="https://github-profile-summary-cards.vercel.app/api/cards/profile-details?username=ADM00103&theme=vue" alt="ADM00103" /></p>

<p>&nbsp;<img align="center" src="https://github-profile-trophy.vercel.app/?username=ADM00103" alt="ADM00103" /></p>

<p>&nbsp;<img align="center" src="https://activity-graph.herokuapp.com/graph?username=ADM00103&theme=dracula" alt="ADM00103" /></p>

<p>&nbsp;<img align="center" src="https://github-profile-summary-cards.vercel.app/api/cards/productive-time?username=adm00103&theme=github_dark" alt="ADM00103" /></p>





